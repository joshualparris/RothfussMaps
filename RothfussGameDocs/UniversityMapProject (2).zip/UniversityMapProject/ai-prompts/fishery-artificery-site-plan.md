Create a top-down architectural site plan of the University grounds from the Kingkiller Chronicle as a canon-constrained reconstruction, not a fantasy invention.

Style:
clean black-and-white planning drawing
architectural site plan
north arrow
simple labels
no decorative fantasy art
no characters
no dramatic lighting
measured, restrained, scholarly presentation

Required constraints:
## 1. What is explicitly known
- Contains artificery workshop spaces
- Has office for artificery master
- Contains exit to roof
- Located near or adjacent to Fishery
- Workshop spaces for artificery work
- Master has private office space

## 2. What is strongly implied
- Industrial workshop building with specialized equipment
- Faculty office for artificery master
- Roof access for ventilation or emergency
- Proximity to related facilities (Fishery)
- Functional workshop architecture

## 3. What is weakly inferred
- Stone construction with workshop modifications
- Multiple workshop rooms and storage
- Ventilation systems for chemical work
- Secure access for dangerous materials
- Proximity to water sources (Fishery)

## 4. What must not be contradicted
- No absence of master's office
- No lack of roof access
- No disconnection from Fishery
- No residential or non-workshop functions
- No inadequate safety measures

## 5. Likely building function and circulation
The Fishery/Artificery serves as workshop complex for artificery with master's office and roof access, functioning as specialized laboratory and manufacturing space. Circulation includes workshop areas, office spaces, and emergency roof egress, with proximity to water-related facilities.

## 6. Likely entrances, stairs, and room zones
- Main workshop entrance
- Master's office access
- Roof exit for ventilation/emergency
- Workshop spaces for artificery work
- Storage areas for materials
- Ventilation and safety systems

## 7. Unknowns that must remain unknown
- Exact workshop configurations
- Specific equipment layouts
- Roof access exact location
- Building size and layout
- Exact relationship to Fishery
- Ventilation system details

## 8. Final reconstruction summary
A workshop building containing artificery spaces with master's office and roof exit, serving as specialized laboratory and manufacturing facility. The building features workshop areas for artificery work, faculty office space, and emergency roof access, located near water-related facilities.

Rules:
- Include only buildings and routes supported by the canon brief.
- If a building position is uncertain, place it conservatively and label it as reconstructed.
- Keep all relative relationships internally consistent.
- Do not invent extra towers, wings, courtyards, or bridges unless listed in the constraints.
- Use a plain map key with:
  canon
  implied
  reconstructed
- Keep the layout practical and believable as a functioning university complex.

Consistency requirements:
- Keep north aligned with the master campus map.
- Keep scale consistent with the approved building shell.
- Preserve previously approved entrances, corridors, stairs, and adjacent rooms.
- Do not contradict earlier approved plans.
- If a new detail would force a contradiction, reject the detail rather than improvising.
