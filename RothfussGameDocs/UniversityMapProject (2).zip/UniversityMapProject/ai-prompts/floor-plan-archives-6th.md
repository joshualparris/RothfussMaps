Create a top-down floor plan for The Archives, 6th Floor, from the Kingkiller Chronicle as a canon-constrained reconstruction.

Use this brief:
## 1. What is explicitly known
- Sixth and top floor of six-story Archives
- Roof accessible via locked interior door, bare stone surface overlooking courtyard
- Primarily restricted access area with emergency/maintenance functions
- Connected to lower floors via vertical circulation
- Part of the overall city-like maze structure

## 2. What is strongly implied
- Limited storage or special collections
- Access control for roof egress
- Vertical circulation hub
- Emergency access points

## 3. What is weakly inferred
- Stone construction matching lower floors
- Functional design for maintenance access
- Restricted lighting and access

## 4. What must not be contradicted
- No windows or natural light
- No general open-flame lighting
- No public spaces
- No direct exterior access except roof
- No straightforward navigation

## 5. Likely building function and circulation
The top floor serves as a transitional zone to the roof, with restricted access for maintenance and emergency purposes. Circulation is limited and controlled, connecting to the lower maze districts.

## 6. Likely entrances, stairs, and room zones
- Locked interior door to roof
- Vertical stairs from lower floors
- Restricted access zones
- Maintenance areas (reconstructed)

## 7. Unknowns that must remain unknown
- Exact layout of top floor
- Specific functions beyond roof access
- Number of access points
- Exact dimensions

## 8. Final reconstruction summary
A six-story square grey stone monolith without windows or exterior decoration, featuring a single obscured stone entrance leading to a two-stage threshold system. The interior forms a city-like maze of book districts with tiered access controls, combining public reading spaces with restricted storage areas. The building emphasizes functional preservation over aesthetic concerns, with complex circulation patterns and emergency access points.

Drawing style:
architectural floor plan
black and white
clear walls, doors, stairs, corridors
room labels
north arrow
scale bar
no people
no decorative fantasy elements

Rules:
- Include only features supported by the canon brief.
- If details are uncertain, keep them minimal and label as reconstructed.
- Keep circulation practical but maze-like.
- Do not invent extra spaces or functions.
- Use plain labels for zones.

Consistency requirements:
- Keep north aligned with the master campus map.
- Keep scale consistent with the approved building shell.
- Preserve previously approved entrances, corridors, stairs, and adjacent rooms.
- Do not contradict earlier approved plans.
- If a new detail would force a contradiction, reject the detail rather than improvising.