Create a top-down floor plan for The Archives, 3rd Floor, from the Kingkiller Chronicle as a canon-constrained reconstruction.

Use this brief:
## 1. What is explicitly known
- Third floor of six-story Archives, primarily Stacks storage districts
- City-like circulation with roads, winding lanes, alleys, and shortcuts
- Stacks: unlit, dark storage requiring hand lamps, cool dry fresh-aired despite no windows
- Well/badly cataloged neighborhoods
- Multi-floor organization with shifted levels
- Potential subareas like Sorting Hall or Bindery

## 2. What is strongly implied
- Extensive shelving systems and storage organization
- Multiple access routes and shortcuts between districts
- Climate-controlled environment for book preservation
- Vertical circulation connecting to other floors
- Hidden service routes for maintenance

## 3. What is weakly inferred
- Stone construction with functional medieval design
- Uneven organization with cataloged and uncataloged areas
- Restricted access zones with controlled lighting
- Integration with ventilation systems
- Emergency access points

## 4. What must not be contradicted
- No windows or natural light
- No general open-flame lighting
- No straightforward navigation
- No evenly lit areas
- No public reading spaces
- No direct exterior access

## 5. Likely building function and circulation
The Archives serves as a restricted knowledge repository with tiered access control, functioning as both public reading space and secure storage facility. Circulation follows an urban maze pattern with multiple route types, requiring wayfinding knowledge. The building prioritizes book preservation through controlled environment and restricted access.

## 6. Likely entrances, stairs, and room zones
- Main entrance: single stone doors on one elevation
- Internal access: two-stage threshold with staffed antechamber
- Vertical circulation: multiple stairwells including southeast in Stacks
- Roof access: locked interior door for emergency/maintenance
- Room zones: public Tomes reading area, restricted Stacks storage, specialized subareas (Scriptorium, Sorting Hall, etc.), acquisitions office, four-plate door landmark

## 7. Unknowns that must remain unknown
- Exact internal layout of city-like maze
- Total number of subareas beyond named ones
- Specific locations of all stairwells
- Exact placement of four-plate door within maze
- Full extent of Underthing connections
- Complete roster of access restrictions
- Exact dimensions and proportions

## 8. Final reconstruction summary
A six-story square grey stone monolith without windows or exterior decoration, featuring a single obscured stone entrance leading to a two-stage threshold system. The interior forms a city-like maze of book districts with tiered access controls, combining public reading spaces with restricted storage areas. The building emphasizes functional preservation over aesthetic concerns, with complex circulation patterns and emergency access points.

Drawing style:
architectural floor plan
black and white
clear walls, doors, stairs, corridors, windows if justified
room labels
north arrow
scale bar
no people
no furniture unless architecturally relevant
no decorative fantasy elements

Rules:
- Respect all adjacency and access constraints from the brief.
- Keep uncertain areas minimal and clearly reconstructed.
- Do not add rooms merely to make the plan feel complete.
- Prefer functional circulation.
- If the building likely has undefined space, leave it as unlabeled service/storage/corridor space rather than inventing specific rooms.
- Make the plan internally consistent with the known exterior access points and neighbouring buildings.

Consistency requirements:
- Keep north aligned with the master campus map.
- Keep scale consistent with the approved building shell.
- Preserve previously approved entrances, corridors, stairs, and adjacent rooms.
- Do not contradict earlier approved plans.
- If a new detail would force a contradiction, reject the detail rather than improvising.
