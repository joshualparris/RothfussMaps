Create a top-down floor plan for The Mews, 2nd Floor, from the Kingkiller Chronicle as a canon-constrained reconstruction.

Use this brief:
## 1. What is explicitly known
- Circular central hub with eight wings radiating outward like a compass rose
- Grey three-story many-windowed building
- Non-Arcanum bunks on fourth floor of east wing, farthest from bathing facilities on ground floor
- Arcanum students housed in west wing
- Mess across lawn to south

## 2. What is strongly implied
- Radial plan with central circulation hub
- Wing-based room assignments by status
- Multi-story structure with vertical circulation
- Ground floor communal bathing facilities
- Status-based segregation in housing

## 3. What is weakly inferred
- Stone construction with multiple windows
- Functional dormitory architecture
- Central hub as main circulation space
- Wing-specific access patterns
- Proximity to dining facilities

## 4. What must not be contradicted
- No simple rectangular dorm block design
- No uniform room assignments across wings
- No bathing facilities above ground floor
- No Arcanum housing in east wing
- No non-Arcanum housing in west wing

## 5. Likely building function and circulation
The Mews serves as student dormitory with status-based housing segregation, functioning as a radial residential complex. Circulation centers on the circular hub with wing-based organization, separating Arcanum and non-Arcanum students while providing communal bathing facilities.

## 6. Likely entrances, stairs, and room zones
- Main entrance from courtyard
- Central circular hub for circulation
- Eight radiating wings (compass directions)
- Vertical stairs between floors
- Ground floor bathing facilities
- East wing: non-Arcanum housing (4th floor bunks)
- West wing: Arcanum housing

## 7. Unknowns that must remain unknown
- Exact room layouts within wings
- Total number of rooms per wing
- Specific bathing facility design
- Central hub exact function
- Window patterns and counts
- Exact dimensions of radial design

## 8. Final reconstruction summary
A three-story grey stone dormitory with a circular central hub and eight radiating wings like a compass rose. The building features status-based housing segregation with Arcanum students in the west wing and non-Arcanum students in the east wing's upper floors, ground floor communal bathing facilities, and proximity to the Mess dining hall across the lawn.

Drawing style:
architectural floor plan
black and white
clear walls, doors, stairs, corridors, windows if justified
room labels
north arrow
scale bar
no people
no furniture unless architecturally relevant
no decorative fantasy elements

Rules:
- Respect all adjacency and access constraints from the brief.
- Keep uncertain areas minimal and clearly reconstructed.
- Do not add rooms merely to make the plan feel complete.
- Prefer functional circulation.
- If the building likely has undefined space, leave it as unlabeled service/storage/corridor space rather than inventing specific rooms.
- Make the plan internally consistent with the known exterior access points and neighbouring buildings.

Consistency requirements:
- Keep north aligned with the master campus map.
- Keep scale consistent with the approved building shell.
- Preserve previously approved entrances, corridors, stairs, and adjacent rooms.
- Do not contradict earlier approved plans.
- If a new detail would force a contradiction, reject the detail rather than improvising.
