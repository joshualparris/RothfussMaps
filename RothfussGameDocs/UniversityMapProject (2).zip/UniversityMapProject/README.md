# University Map Project

This workflow is built to help you reconstruct the University as accurately and consistently as possible from canon evidence before you ask any AI to visualize it. The core rule is simple: do not let an image model decide layout. First lock the evidence, then lock the map, then lock each building, then generate visuals.

## Best Workflow

1. Build an evidence ledger from lawful copies of `TNOTW` and `TWMF`.
2. Convert every spatial clue into a short structured constraint.
3. Separate each constraint into:
   - `Tier 1`: directly confirmed
   - `Tier 2`: strongly implied
   - `Tier 3`: design inference needed to make the space usable
4. Freeze a campus layout before touching building interiors.
5. Freeze each building brief before touching floor plans.
6. Freeze each floor plan before touching individual rooms.

If you skip those freeze points, later prompts will drift and contradict each other.

## Why Direct Image Generation Is Weak

Image models are good at atmosphere and presentation, but weak at:

- counting rooms consistently
- preserving door and stair relationships
- respecting exact adjacency rules
- maintaining one building across multiple generations

For exact floor plans, use a text model first to produce a structured building spec or JSON layout. Use image generation only after the structure is locked.

## Research Rules

- Store short excerpts only. Prefer paraphrase plus page reference over long quotes.
- Treat every spatial claim as evidence, not truth, until it is logged.
- Record contradictions instead of smoothing them away.
- Mark unknowns as unknowns.
- When the books do not support a precise answer, make one explicit design decision and log it.

## Folder Contents

- `evidence-ledger.csv`
  Populated evidence ledger with all spatial constraints from canon.
- `campus-layout.md`
  Synthesized campus layout with confirmed adjacencies and design inferences.
- `buildings/`
  Frozen building briefs for each major structure (Mains, Archives, Mews, etc.).
- `floorplans/`
  JSON specifications for building floor plans with structured constraints.
- `reconstruction-briefs/`
  Canon-constrained reconstruction briefs for all buildings using the 8-section format.
- `ai-prompts/`
  Ready-to-use site plan prompts for Gemini/Nano Banana image generation, one per building with canon constraints; plus floor plan prompts for each building floor with detailed spatial constraints; plus room plan prompts for key canon-described rooms with specific evidence and context.
- `ai-generation-guide.md`
  Complete guide for consistent AI image generation.
- `evidence-ledger-template.csv`
  Use this as the master dataset for every spatial clue.
- `decision-log-template.md`
  Use this whenever two clues conflict or canon leaves a gap.
- `floorplan-schema-template.json`
  Use this as the structured output target before image generation.
- `prompt-templates.md`
  Ready-to-fill prompts for extraction, synthesis, floor plans, and rooms.
- `generate_prompt.py`
  Generates a consistent prompt from your filled evidence ledger.

## Recommended Pipeline

### Phase 1: Campus Evidence

Track every reference to:

- the Mains
- the Archives
- the Medica
- the Fishery
- the Artificery
- the Mews
- courtyards
- roads and paths
- Stonebridge and the river approach
- any approach sequence such as "from X to Y"

Your job here is not to draw. Your job is to collect constraints.

### Phase 2: Campus Synthesis

Use the ledger to answer:

- Which locations are definitely adjacent?
- Which directions are actually supported?
- Which routes are sequential but not directional?
- Which buildings have exterior traits that affect map shape?
- Which spaces are inside other spaces?

Lock a campus version only after you have answered those.

### Phase 3: Building Briefs

For each building, create a brief with:

- what is canon-confirmed
- what is canon-implied
- what is inferred for playability
- entrances and exits
- vertical movement
- major rooms or functions
- features that must not appear

### Phase 4: Floor Plans

Before using image generation, produce a structured floor plan spec. Keep it architectural and constraint-driven:

- floor count
- main circulation
- room adjacency

### Phase 5: AI Generation

Use the provided prompts in `/ai-prompts/` with Gemini/Nano Banana:

1. Generate floor plans first (technical drawings)
2. Generate building exteriors
3. Generate individual room interiors
4. Maintain consistency across all generations

## Quick Start

1. Review `evidence-ledger.csv` and `campus-layout.md`
2. Choose a building from `buildings/`
3. Check its floor plan spec in `floorplans/`
4. Use the corresponding prompt in `ai-prompts/`
5. Follow the `ai-generation-guide.md` for consistent results

## Key Findings Integrated

- **Evidence Ledger**: 83 total entries (49 TNOTW + 13 additional TNOTW + 12 WMF + 9 duplicates avoided), tiered certainty system preventing invention
- **Site Plan Prompts**: All major buildings have ready-to-use AI prompts for top-down architectural site plans, each incorporating full reconstruction brief constraints
- **Floor Plan Prompts**: All major buildings have floor plan prompts for known floors (Archives 5 floors, Mews 3 floors, others ground floor), with detailed spatial and circulation constraints
- **Room Plan Prompts**: Key canon-described rooms have individual prompts with room-specific evidence and building context (Tomes, Stacks, Admissions Theatre, etc.)
- **Reconstruction Briefs**: All major buildings reconstructed using 8-section format with explicit/implied/inferred distinctions, preserving unknowns and contradictions
- **Archives**: 5-story square grey windowless monolith, city-like internal maze, two-stage entrance with TOMES/STACKS/SCRIVS branching, ledger-controlled access, tiered sanctions, roof access via locked door overlooking courtyard
- **Mains**: Irregular accreted complex covering 1.5 acres, maze-like circulation, absorbed courtyards accessible only by climbing, theatre-style lecture rooms with tiered seating, roof access via drainpipes and apple tree descent to courtyard
- **Mews**: Radial hub-and-spoke with 8 wings, 3 stories, east/west wing assignments, ground baths
- **Campus**: ~15 buildings, University west of Imre across Omethi canyon via Stonebridge, hosts over 1000 students with major 11-day admissions process, central House of the Wind courtyard for public events
- **Hollows**: Square with stained glass, admissions theatre with raised masters' table, back entrance with locks, Elodin's office and tiered lecture hall
- **Masters' Hall**: Grey stone with stained glass, residential quarters for masters/gillers/guests, large windowless room with crescent table
- **Fishery/Artificery**: Industrial complex with craft shops, Kilvin's office with forge, southern exit, eastern windows, elevated walkways
- **Administrative**: Ledgers and Lists for course registration; bursar's office with basement access
- **Haven**: Manor-like north of campus, 10-foot fence, huge capacity, formal interior with marble staircase, padded patient rooms, high-containment cells
- **Underthing**: Extensive network with named zones (Nodway, Vaults, Billows, Woods with structural supports, Cricklet with water, Belows with deep ventilation)
- room function
- window rules
- stair rules
- restricted areas

### Phase 5: Room Pass

Generate rooms one by one only after the floor plan is frozen. Each room prompt should inherit:

- building identity
- floor identity
- adjacent spaces
- lighting rules
- entry and exit count
- furniture and function
- known lore interactions

## Prompt Generation

Once your CSV has real evidence in it, run:

```bash
python3 RothfussGameDocs/UniversityMapProject/generate_prompt.py \
  --csv RothfussGameDocs/UniversityMapProject/evidence-ledger-template.csv \
  --mode campus
```

For a building:

```bash
python3 RothfussGameDocs/UniversityMapProject/generate_prompt.py \
  --csv RothfussGameDocs/UniversityMapProject/evidence-ledger-template.csv \
  --mode building \
  --target "the Archives"
```

For a floor plan:

```bash
python3 RothfussGameDocs/UniversityMapProject/generate_prompt.py \
  --csv RothfussGameDocs/UniversityMapProject/evidence-ledger-template.csv \
  --mode floor \
  --target "the Archives"
```

For a room:

```bash
python3 RothfussGameDocs/UniversityMapProject/generate_prompt.py \
  --csv RothfussGameDocs/UniversityMapProject/evidence-ledger-template.csv \
  --mode room \
  --target "the Archives"
```

## Practical Advice

- Use one text model for extraction and synthesis.
- Use one image model only for visualization after structure is locked.
- Keep a single north reference for the whole project.
- Version everything: `campus_v1`, `archives_v1`, `archives_floor_1_v1`.
- Never overwrite a frozen version without logging why.

## Strongest Working Principle

Do not ask, "What does the University probably look like?"

Ask, "What does canon require, what does canon imply, what remains unknown, and what single explicit design choice best bridges each gap without breaking tone or internal logic?"
