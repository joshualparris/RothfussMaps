Create a top-down room plan for Dining Hall in Mess as a canon-constrained reconstruction.

Known constraints:
- Large communal dining facility
- Serves meals to students and faculty
- Communal eating space
- Part of university dining operations
- Regular meal service

Building/floor context:
- Ground floor of university dining hall
- Located across lawn to south of Mews
- Contains large dining spaces and kitchen areas
- Food service center for students and faculty
- Organized meal distribution

Rules:
- This room must fit the already-established building shell and floor circulation.
- Do not change doorway placement or corridor logic from the approved floor plan.
- Do not invent furnishings or architectural features without support.
- Prefer sparse, practical, lived-in realism.
- If a feature is uncertain, keep it minimal and architecturally neutral.
- Match materials, light, and function to the canon brief.