Create a top-down architectural site plan of the University grounds from the Kingkiller Chronicle as a canon-constrained reconstruction, not a fantasy invention.

Style:
clean black-and-white planning drawing
architectural site plan
north arrow
simple labels
no decorative fantasy art
no characters
no dramatic lighting
measured, restrained, scholarly presentation

Required constraints:
## 1. What is explicitly known
- Contains masters' offices and meeting spaces
- Elodin has an office in Masters' Hall
- Masters' offices are private spaces for faculty
- Contains meeting spaces for faculty governance

## 2. What is strongly implied
- Administrative and faculty-focused building
- Private office spaces for individual masters
- Formal meeting areas for university governance
- Proximity to other administrative buildings

## 3. What is weakly inferred
- Stone construction typical of university buildings
- Multiple office spaces and meeting rooms
- Functional administrative architecture
- Central location in university complex

## 4. What must not be contradicted
- No student access to masters' offices
- No public meeting spaces
- No absence of individual faculty offices
- No disconnection from university governance

## 5. Likely building function and circulation
Masters' Hall serves as faculty administrative center with private offices and meeting spaces, functioning as the governance hub for university masters. Circulation is restricted to faculty with private access to individual offices and formal meeting areas.

## 6. Likely entrances, stairs, and room zones
- Restricted faculty entrance
- Individual masters' offices
- Meeting spaces for faculty governance
- Private circulation corridors

## 7. Unknowns that must remain unknown
- Exact number of masters' offices
- Specific office assignments
- Meeting room configurations
- Building size and layout
- Exterior appearance
- Exact location relative to other buildings

## 8. Final reconstruction summary
A faculty administrative building containing private masters' offices and meeting spaces for university governance. The building serves as the restricted administrative center for faculty members, with individual office spaces and formal meeting areas for university decision-making.

Rules:
- Include only buildings and routes supported by the canon brief.
- If a building position is uncertain, place it conservatively and label it as reconstructed.
- Keep all relative relationships internally consistent.
- Do not invent extra towers, wings, courtyards, or bridges unless listed in the constraints.
- Use a plain map key with:
  canon
  implied
  reconstructed
- Keep the layout practical and believable as a functioning university complex.