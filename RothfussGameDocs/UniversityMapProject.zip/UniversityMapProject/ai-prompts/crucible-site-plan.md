Create a top-down architectural site plan of the University grounds from the Kingkiller Chronicle as a canon-constrained reconstruction, not a fantasy invention.

Style:
clean black-and-white planning drawing
architectural site plan
north arrow
simple labels
no decorative fantasy art
no characters
no dramatic lighting
measured, restrained, scholarly presentation

Required constraints:
## 1. What is explicitly known
- Contains crucible for sympathy work
- Sympathy workshop and laboratory space
- Specialized facility for sympathy experimentation
- Contains sympathy equipment and materials

## 2. What is strongly implied
- Dedicated sympathy laboratory building
- Specialized equipment for sympathy work
- Secure facility for dangerous sympathy experiments
- Professional sympathy workspace

## 3. What is weakly inferred
- Stone construction with laboratory modifications
- Multiple sympathy work areas
- Storage for sympathy materials
- Ventilation and safety systems
- Controlled environment for sympathy work

## 4. What must not be contradicted
- No absence of crucible equipment
- No lack of sympathy workspace
- No non-sympathy functions
- No inadequate safety measures
- No disconnection from sympathy education

## 5. Likely building function and circulation
The Crucible serves as sympathy laboratory with specialized equipment and workspace, functioning as experimental facility for sympathy work. Circulation includes laboratory areas, equipment rooms, and storage spaces with safety considerations for sympathy experimentation.

## 6. Likely entrances, stairs, and room zones
- Main laboratory entrance
- Sympathy work areas with crucibles
- Equipment and material storage
- Safety and ventilation systems
- Staff and instructor spaces
- Controlled experimental zones

## 7. Unknowns that must remain unknown
- Exact crucible configurations
- Specific sympathy equipment
- Safety system details
- Building size and layout
- Ventilation exact design
- Exact location on campus

## 8. Final reconstruction summary
A sympathy laboratory facility containing crucibles and specialized equipment for sympathy work. The building serves as experimental workspace with laboratory areas, equipment storage, and safety systems, providing controlled environment for sympathy experimentation and education.

Rules:
- Include only buildings and routes supported by the canon brief.
- If a building position is uncertain, place it conservatively and label it as reconstructed.
- Keep all relative relationships internally consistent.
- Do not invent extra towers, wings, courtyards, or bridges unless listed in the constraints.
- Use a plain map key with:
  canon
  implied
  reconstructed
- Keep the layout practical and believable as a functioning university complex.