# AI Image Generation Prompt: The Archives - Floor Plan

Use this prompt with Gemini/Nano Banana for generating floor plans. Generate the entire floor first, then individual rooms.

## Base Style Guidelines (include in all prompts):
- Medieval university architecture: stone walls, wooden beams, arched doorways
- Atmospheric lighting: natural light through windows, lanterns, dust motes
- Canon-consistent: worn stone floors, academic atmosphere, constant activity
- Technical drawing style: clear labels, scale indicators, north arrow
- Color palette: earth tones, aged materials, subtle lighting

## Floor Plan Generation Prompt:

Generate a detailed architectural floor plan for The Archives, the monolithic restricted library of the University from Patrick Rothfuss's Kingkiller Chronicle.

Building specifications:
- Five-story square grey stone monolith, windowless and featureless
- Single great stone entrance that Kvothe has to circle around to find
- Two-stage entry: stone doors into small antechamber, then wooden doors to interior
- Antechamber branches to: TOMES (double doors), STACKS (double doors), SCRIVS ONLY (smaller door)
- Internal layout like a city with roads, winding lanes, alleys, and shortcuts
- Multiple subareas: Scriptorium, Sorting Hall, Buggery, Cataloger's Mew, Bindery, Bolts, Palimpsest, acquisitions office
- Acquisitions office: tiny perpetually dark room with huge lacquered map on one wall
- Stacks: multi-floor (two floors once shifted), southeast stairwell identified
- Four-plate door as central landmark
- Connected to Underthing via ventilation tunnels

Key features to include:
- Exterior: square grey windowless monolith with single obscured stone entrance
- Antechamber: small space with three branching doors clearly labeled
- Tomes: large high-ceilinged well-lit reading room with long tables
- Stacks: dark maze-like storage requiring hand lamps, cool dry air
- City-like circulation with multiple paths and shortcuts
- Multiple stairwells including southeast
- Specialized areas for different book functions

Output: Clean architectural floor plan with:
- Clear room boundaries and labels
- Door and window symbols (no windows in building)
- Scale reference
- North arrow pointing up
- Legend explaining symbols
- Security/access indicators
- Multiple floor levels shown

## Individual Room Prompts (generate after floor plan):

### Antechamber:
Generate an interior view of the Archives antechamber.

Key elements:
- Small stone room after outer doors
- Three doors: large double doors to TOMES, large double doors to STACKS, smaller door labeled SCRIVS ONLY
- Desk for access control
- Functional, security-focused space
- Stone walls, minimal decoration

Style: Atmospheric medieval security threshold, functional stone architecture.

### Tomes Reading Room:
Generate an interior view of the Tomes reading room.

Key elements:
- Large high-ceilinged space
- Long wooden tables with chairs
- Shelving with core class texts
- Well-lit with natural light (despite building being windowless - imply clerestory or other means)
- Students studying quietly
- Academic atmosphere with books and concentration

Style: Atmospheric medieval library, scholarly and well-lit.

### The Stacks Maze:
Generate an interior view of the Stacks storage area.

Key elements:
- Narrow aisles between tall wooden shelving
- Books densely packed on shelves
- Very dim lighting, hand lamps required
- Cool, dry air with dust motes
- Maze-like arrangement with multiple paths
- Stone floor, high ceilings
- Quiet, reverent atmosphere

Style: Atmospheric medieval archive, dark and mysterious, focus on depth and storage.

### Acquisitions Office:
Generate an interior view of the acquisitions office.

Key elements:
- Tiny room, perpetually dark
- One wall dominated by huge lacquered map showing cities, roads, book acquisition teams
- Small desk and chair
- Minimal lighting
- Administrative, map-focused space

Style: Atmospheric medieval administrative office, dark and detailed.