Create a top-down floor plan for Mess, Ground Floor, from the Kingkiller Chronicle as a canon-constrained reconstruction.

Use this brief:
## 1. What is explicitly known
- University dining hall
- Located across lawn to south of Mews
- Serves meals to students and faculty
- Communal dining facility

## 2. What is strongly implied
- Large dining space for community meals
- Kitchen and food preparation areas
- Proximity to student housing (Mews)
- Regular meal service operations

## 3. What is weakly inferred
- Stone construction with dining modifications
- Large hall for communal eating
- Kitchen facilities and storage
- Serving and dining areas
- Functional dining architecture

## 4. What must not be contradicted
- No disconnection from Mews
- No lack of dining capacity
- No absence of kitchen facilities
- No non-dining functions
- No inadequate meal service

## 5. Likely building function and circulation
The Mess serves as university dining hall with communal eating spaces, functioning as food service center for students and faculty. Circulation includes dining areas, kitchen spaces, and service areas with organized meal distribution.

## 6. Likely entrances, stairs, and room zones
- Main dining entrance
- Large communal dining hall
- Kitchen and food preparation areas
- Storage and pantry spaces
- Serving and distribution areas
- Staff and service corridors

## 7. Unknowns that must remain unknown
- Exact dining capacity
- Kitchen configurations
- Menu and meal details
- Building size and layout
- Service exact organization
- Interior dining arrangements

## 8. Final reconstruction summary
A university dining hall located across the lawn south of the Mews, serving as communal eating facility for students and faculty. The building contains large dining spaces, kitchen areas, and food service operations, providing regular meal service to the university community.

Drawing style:
architectural floor plan
black and white
clear walls, doors, stairs, corridors, windows if justified
room labels
north arrow
scale bar
no people
no furniture unless architecturally relevant
no decorative fantasy elements

Rules:
- Respect all adjacency and access constraints from the brief.
- Keep uncertain areas minimal and clearly reconstructed.
- Do not add rooms merely to make the plan feel complete.
- Prefer functional circulation.
- If the building likely has undefined space, leave it as unlabeled service/storage/corridor space rather than inventing specific rooms.
- Make the plan internally consistent with the known exterior access points and neighbouring buildings.