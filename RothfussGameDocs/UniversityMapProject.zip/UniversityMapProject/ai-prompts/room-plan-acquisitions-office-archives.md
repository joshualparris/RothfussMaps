Create a top-down room plan for Acquisitions Office in The Archives as a canon-constrained reconstruction.

Known constraints:
- Tiny perpetually dark room
- Huge lacquered map on one wall
- Acquisitions office for book procurement
- Part of Archives administrative functions
- Located within the city-like maze

Building/floor context:
- Ground floor of five-story square grey windowless monolithic block
- Part of city-like internal maze with roads, winding lanes, alleys, and shortcuts
- Contains specialized subareas like Scriptorium, Sorting Hall, Buggery, Cataloger's Mew, Bindery, Bolts, Palimpsest, acquisitions office
- Acquisitions office is a small administrative space within the larger Archives complex
- Connected to main circulation routes and storage areas

Rules:
- This room must fit the already-established building shell and floor circulation.
- Do not change doorway placement or corridor logic from the approved floor plan.
- Do not invent furnishings or architectural features without support.
- Prefer sparse, practical, lived-in realism.
- If a feature is uncertain, keep it minimal and architecturally neutral.
- Match materials, light, and function to the canon brief.