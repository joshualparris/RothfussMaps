# University of Imre Campus Layout Synthesis

## Locked Campus Constraints
- **Approach Route**: University lies west of Imre settlement, connected by Stonebridge across Omethi River canyon
- **Settlement Context**: Imre functions as gateway town for road travellers; University is embedded in orderly town-sized settlement with wide roads, clean air, lawns, gardens, and specialist shops; Imre streets busier at night with social activity
- **Topography**: Omethi River forms major rocky canyon barrier between Imre and University approach
- **Bridge**: Stonebridge is ancient 200+ foot stone crossing, wagon-wide, visually dominant from crest
- **Campus Scale**: ~15 architecturally varied buildings in service-oriented academic town; University hosts over 1000 students with major 11-day admissions process requiring outdoor queueing
- **Central Courtyard**: House of the Wind (formerly Quoyan Hayel) is wide cobblestone courtyard for public disciplinary events, surrounded by buildings with accessible windows, doors, and rooftops for spectators
- **Archives**: 5-story square grey windowless monolithic block, visually dominant from bridge, city-like internal maze with two-stage entry (stone doors → antechamber → TOMES/STACKS/SCRIVS), ledger-controlled access, tiered sanctions system, roof accessible via locked door overlooking courtyard
- **Mains**: Accreted irregular complex covering nearly 1.5 acres, maze-like circulation with absorbed courtyards (some isolated), theatre-style lecture rooms, roof access via drainpipes and apple tree descent to courtyard
- **Mews**: Radial hub-and-spoke with 8 wings, 3 stories, east wing non-Arcanum (4th floor bunks), west wing Arcanum, ground floor baths, Mess across lawn to south
- **Medica**: Large irregular building opposite Archives from Mains, taller than Mains but less rambling, treats sick and allows debt-work
- **Fishery/Artificery**: Industrial complex with craft shops (glassblowers, joiners, potters, glaziers), forge, smelt-works, Kilvin's office with forge/glasswork, southern exit to courtyard, eastern windows with morning sunlight, Kilvin's granary-sized workshop with elevated iron walkways
- **Hollows**: Square building with stained glass (Teccam), admissions theatre with raised masters' table, back entrance with locks, Elodin's unused office, Elodin's tiered lecture hall entered from hallway above, reached "down then left" from Archives
- **Masters' Hall**: Large windowless room with crescent table (not elevated), reached via Hollows/Jamison route, contains masters' quarters, gillers, guest rooms
- **Haven**: Manor-like institution north of campus via forest road, 10-foot unclimbable fence, huge with red tile roof, formal grounds, interior with marble staircase and padded patient rooms
- **Administrative**: Ledgers and Lists for course registration; bursar's office in separate stone building reached via courtyard, hall, and basement stairs
- **Underthing**: Extensive subterranean network with named routes (Nodway, Vaults, Billows, Woods, Cricklet, Belows), steam-heated spaces, structural failures in Woods requiring supports, water-fed Cricklet with crickets, deep Belows with rushing wind, connects to Archives ventilation, surface grates for access
- **Additional**: Crucible (chemical with bristling chimneys), Stocks (Fishery storeroom), four-plate door (Archives landmark)

## Contradictions or Ambiguities
- Exact global orientation of all buildings relative to each other still partially undetermined
- Hollows adjacency to Archives confirmed but global position relative to campus unclear
- Masters' Hall and Crucible locations not fully anchored
- Whether University town description applies only to campus area or includes Imre settlement

## Proposed Campus Layout Logic
The University forms an irregular academic cluster west of Imre across the Omethi canyon, with Stonebridge as the chokepoint. The Archives serves as the eastern visual anchor and access control point. The Mains acts as the accreted central hub with cardinal connections. Student housing (Mews) and services cluster to the west, while industrial/production buildings (Fishery, Medica) occupy the southern areas. Administrative functions (Hollows, Masters' Hall, bursar) cluster near Archives. Haven stands isolated to the north as a secured institutional facility.

## Explicit Design Inferences
- Campus spans significant area with wide roads and green spaces between buildings
- Buildings show architectural variety: monolithic (Archives), accreted (Mains), radial (Mews), industrial (Fishery), formal (Hollows, Masters' Hall)
- Production buildings (Medica, Fishery, Crucible) are working facilities with loading areas and trade connections
- Underthing access points exist throughout campus, particularly near Archives and Mains
- Multiple access patterns: public routes, back entrances, roof access, subterranean connections
- Status-based segregation in housing and access (Arcanum/non-Arcanum, ledger registration)

## Clean Adjacency List
- **Imre**: E-Stonebridge, settlement gateway
- **Stonebridge**: E-Imre, W-University approach, crosses Omethi canyon
- **Archives**: W-Mains, E-Hollows (down/left), S-Medica, internal city-maze, Underthing connections
- **Mains**: E-Archives, N-Fishery/Artificery, S-Medica, W-Courtyard, internal maze with isolated courtyards
- **Mews**: W-campus, S-Mess (across lawn), radial with 8 wings, ground baths
- **Mess**: N-Mews (across lawn), dining hall seating 200+
- **Medica**: N-Mains, NE-Archives, large irregular medical facility
- **Fishery/Artificery**: S-Mains, industrial complex with workshops and Stocks
- **Hollows**: W-Archives (up/right from Archives), contains admissions theatre, back entrance, Elodin's office
- **Masters' Hall**: Accessed via Hollows/Jamison route, large windowless room with crescent table
- **Haven**: N-University (forest road), manor-like with 10-foot fence, formal grounds, padded rooms
- **Bursar**: Separate stone building via courtyard from main areas, basement location
- Archives: W-Mains, E-Hollows (nearby), S-Medica (opposite side)
- Courtyard: N-Mews, E-Mains, W-Anker's/Mess
- Mews: S-Courtyard, radial wings with east/west assignments
- Fishery/Artificery: S-Mains, industrial complex with multiple shops
- Haven: N-campus edge, isolated manor compound
- Underthing: Connected to surface via grates, tunnels to Archives

## Compact Campus Blueprint Brief
Irregular medieval university campus west of Imre, centered on accreted Mains building with monolithic Archives as eastern anchor. Radial Mews dormitory to west, industrial Fishery complex to north, large Medica to south. Manor-like Haven isolated to north. Extensive subterranean Underthing network. ~15 varied buildings in town-sized settlement.