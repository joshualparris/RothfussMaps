# University Map AI Generation Guide

This guide helps you generate consistent, canon-accurate visuals for the University of Imre using AI image generation tools like Gemini/Nano Banana.

## Workflow Overview

1. **Read the Evidence**: Review the evidence-ledger.csv and campus-layout.md
2. **Choose Building**: Select a building brief from /buildings/
3. **Review Floor Plan**: Check the JSON spec in /floorplans/
4. **Generate Floor Plan**: Use the prompt in /ai-prompts/ for the building
5. **Generate Room Interiors**: Use individual room prompts after floor plan approval
6. **Iterate**: If inconsistencies appear, reference the frozen specs

## Consistency Rules

### Style Guidelines (include in EVERY prompt):
- **Architecture**: Medieval university - stone walls, wooden beams, arched doorways, worn stone floors
- **Lighting**: Atmospheric - natural light through windows, lanterns, dust motes, subtle shadows
- **Materials**: Earth tones, aged stone, weathered wood, practical metals
- **Atmosphere**: Academic focus, constant activity, sensory details from canon
- **Technical**: Clean architectural drawings with labels, scales, north arrows

### Content Rules:
- **No Inventions**: Only include elements from briefs or explicitly inferred
- **Canon Priority**: Features from books override assumptions
- **Consistency**: Use same style across all generations for the same building
- **Scale**: Medieval proportions, functional not decorative

## Prompt Structure

Each AI prompt follows this structure:

1. **Context**: Building name, purpose, canon source
2. **Specifications**: Dimensions, layout from JSON spec
3. **Key Features**: Required elements from brief
4. **Style Requirements**: Visual consistency guidelines
5. **Output Format**: Technical drawing vs atmospheric rendering

## Available Prompts

- **mains-ground-prompt.md**: The Mains ground floor and main hall
- **archives-prompt.md**: The Archives exterior, reading room, and stacks
- **mews-prompt.md**: The Mews corridor and student rooms

## Tips for Best Results

- **Start with Floor Plans**: Generate technical floor plans before interiors
- **Reference JSON**: Include specific room connections and constraints
- **Batch Generation**: Generate all rooms for one building together for consistency
- **Version Control**: Save each generation with version numbers
- **Review Against Canon**: Check outputs against book descriptions

## Example Full Prompt

```
Generate a detailed architectural floor plan for the ground floor of The Mains...

[specs from JSON]

Key features: central hall, four exits, central staircase...

[style guidelines]

Output: Clean technical drawing with labels, scale, north arrow...
```

This framework ensures your AI-generated maps remain faithful to Rothfuss's vision while being visually consistent and useful for your project.