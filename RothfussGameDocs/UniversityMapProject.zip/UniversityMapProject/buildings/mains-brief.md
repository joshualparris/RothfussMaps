# The Mains - Building Brief

## Building Identity
Accreted central hub building of the University, oldest structure grown irregularly over time.

## Confirmed Facts
- Covers nearly 1.5 acres and looks cobbled together from mismatched buildings
- Oldest University building, grown slowly in all directions engulfing smaller buildings and courtyards
- Maze-like circulation with odd turns, dead ends, rambling routes, and shortcuts through workrooms
- At least one courtyard completely isolated, accessible only by climbing through a window
- Contains theatre-style lecture rooms with tiered semicircular seating around raised stages and stone worktables
- Roof accessible via drainpipes in sheltered box alley

## Implied Facts
- Multi-level structure with absorbed spaces
- Irregular footprint, not symmetrical
- Contains trapped or awkwardly accessible internal voids

## Explicit Design Inferences
- Stone construction with accreted additions over time
- Complex internal layout with multiple wings and absorbed courtyards
- Exterior drainpipes and narrow alleys for roof access

## Exterior Shell
Irregular accreted complex, approximately 1.5 acres, multi-story with mismatched architecture.

## Entrances and Circulation
- Multiple entrances in all directions (north, east, south, west)
- Labyrinthine internal circulation with odd turns and dead ends
- Shortcuts through workrooms and lecture halls
- Roof access via drainpipes

## Required Room Functions
- Lecture halls (absorbed into larger complex)
- Workrooms (for shortcuts)
- Absorbed courtyards (some isolated)
- Administrative spaces

## Hard Bans
- No symmetrical or uniform design
- No straightforward internal navigation
- No modern accretions

## Open Questions
- Exact number of absorbed buildings/courtyards
- Current vs historical layout distinctions

## Final Frozen Brief
Irregular accreted stone complex covering 1.5 acres, grown over centuries with absorbed buildings and courtyards. Maze-like internal circulation with odd turns, dead ends, and isolated spaces. Medieval academic labyrinth with historical layering.