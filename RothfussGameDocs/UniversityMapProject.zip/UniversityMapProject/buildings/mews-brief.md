# The Mews - Building Brief

## Building Identity
Radial hub-and-spoke student dormitory with wing-specific assignments and status divisions.

## Confirmed Facts
- Circular central hub with eight wings radiating outward like compass rose
- Three stories tall, grey stone, many-windowed
- East wing: non-Arcanum bunks on fourth floor, farthest from ground floor bathing facilities
- West wing: Arcanum students housed there
- Ground floor: bathing facilities
- Mess across lawn to the south

## Implied Facts
- Hub-and-spoke radial layout, not rectangular
- Wing-specific and floor-specific room assignments
- Shared bathing facilities on ground floor
- Status-based housing segregation

## Explicit Design Inferences
- Central circular hub with radiating corridors/wings
- Multi-story with vertical circulation between floors
- Ground floor communal facilities
- Upper floors residential with wing distinctions

## Exterior Shell
Radial grey stone building with central hub and eight radiating wings, three stories, many windows.

## Entrances and Circulation
- South entrance from courtyard
- Central hub with radiating corridors to wings
- Stairs between floors
- Ground floor access to bathing facilities

## Required Room Functions
- Central hub (circulation)
- East wing rooms (non-Arcanum, upper floors)
- West wing rooms (Arcanum)
- Ground floor bathing facilities
- Possible communal areas

## Hard Bans
- No rectangular dormitory design
- No uniform room assignments
- No upper floor bathing facilities

## Open Questions
- Exact room distribution in each wing
- Additional facilities beyond bathing

## Final Frozen Brief
Three-story radial grey stone dormitory with circular central hub and eight radiating wings. East wing for non-Arcanum students (upper floors), west wing for Arcanum, ground floor bathing facilities. Hub-and-spoke medieval university residence with status-based segregation.