# Haven - Building Brief

## Building Identity
Manor-like asylum and institutional facility north of campus, secured by high fence.

## Confirmed Facts
- Huge manor-like building bigger than the Artificery, with red tile roof, high windows, arched doorways, pillars, fountains, flowers, and hedges
- Enclosed by nearly ten-foot-tall wrought-iron fence that is effectively unclimbable
- Huge entryway with stained glass windows and vaulted ceilings
- Wide marble staircase and long white hallways lined with wooden doors
- Patient rooms with different restraint/security setups
- Alder Whin's room: tall windows, bed and table/chairs, but walls/ceiling/floor padded with thick white cloth for sound muffling
- Elodin's former cell: different wing, solid copper door, bare grey stone walls, strange pressure/heaviness in air, huge windows with reddish streaks and copper frames, no interior door handle, visible balcony with no obvious access
- Guard estimates roughly 320-350 people currently, room for another 150

## Implied Facts
- Large institutional capacity with specialized room designs
- High-security containment for dangerous individuals
- Formal institutional architecture despite asylum function
- Multiple wings with different security levels

## Explicit Design Inferences
- Expansive formal manor with institutional security features
- Sound-suppression and safety padding in patient rooms
- High-containment chambers using copper and reinforced glazing
- Anti-escape design elements (no door handles, inaccessible balconies)
- Prestigious institutional entrance despite security focus

## Exterior Shell
Huge manor with red tile roof, formal grounds, fountains, gardens, and 10-foot wrought-iron fence.

## Entrances and Circulation
- Main entryway with stained glass and vaulted ceilings
- Wide marble staircase to upper levels
- Long white hallways with wooden patient room doors
- Separate wings for different patient types/security levels

## Required Functions
- Large institutional capacity (470+ people)
- Patient rooms with varying security levels
- Sound-muffled safety rooms
- High-containment cells for dangerous arcanists
- Formal administrative intake with ledgers
- Guarded perimeter security