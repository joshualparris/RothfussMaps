# The Archives - Building Brief

## Building Identity
Monolithic restricted library and knowledge repository, described as a city unto itself.

## Confirmed Facts
- Five stories tall, square, grey, windowless, featureless, larger than stacked granaries
- One great stone entrance, not immediately obvious (Kvothe circles to find it)
- Two-stage entry: stone doors to small antechamber, then wooden doors to interior
- Antechamber branches to TOMES (double doors), STACKS (double doors), SCRIVS ONLY (smaller door)
- Entry hall is active staffed threshold space where permissions are managed before deeper access
- Access controlled by ledger registration ("in the book") after admissions
- Stack access is separately controlled with fees, distinct from Tomes, requires hand lamps
- Tomes: large high-ceilinged well-lit main reading room with long tables and core texts
- Stacks: unlit, dark storage requiring hand lamps, cool dry fresh-aired despite no windows
- Internal circulation like a city with roads, winding lanes, alleys, shortcuts
- Subareas: Scriptorium, Sorting Hall, Buggery, Cataloger's Mew, Bindery, Bolts, Palimpsest, acquisitions office
- Acquisitions office: tiny perpetually dark room with huge lacquered map on one wall
- Stacks organization: well/badly cataloged neighborhoods, multi-floor (two floors once shifted)
- Four-plate door at heart of Archives city
- Southeast stairwell in Stacks
- Connected to Underthing via ventilation tunnels

## Implied Facts
- Massive internal volume for city-like navigation
- Complex vertical circulation with multiple stairwells
- Extensive shelving and storage systems
- Hidden service routes and maintenance areas

## Explicit Design Inferences
- Severe monolithic exterior with single obscured entrance
- Internal urban maze of book districts and specialized areas
- Climate-controlled environment with unseen ventilation
- Restricted access zones with security features

## Exterior Shell
Square grey stone monolith, 5 stories tall, windowless, featureless, with single great stone entrance.

## Entrances and Circulation
- Main entrance: stone doors to antechamber
- Antechamber branches: Tomes, Stacks, Scrivs Only
- Internal city-like navigation with roads, lanes, alleys, shortcuts
- Multiple stairwells (southeast identified)
- Hidden Underthing access via ventilation

## Required Room Functions
- Antechamber (reception with branching doors)
- Tomes (main reading room, well-lit)
- Stacks (dark storage maze, multi-floor)
- Scriptorium (copying/scripting)
- Sorting Hall (processing)
- Acquisitions office (tiny dark map room)
- Bindery, Bolts, Palimpsest (specialized areas)
- Four-plate door (central landmark)

## Hard Bans
- No windows anywhere
- No exterior ornamentation
- No multiple public entrances
- No even lighting in Stacks (hand lamps only)
- No open flames in Stacks

## Open Questions
- Exact layout of city-like districts
- Full extent of Underthing connections

## Final Frozen Brief
Five-story square grey windowless stone monolith with obscured single entrance and two-stage threshold. Internal city-like maze of book districts with specialized areas, dark Stacks requiring portable light, and central four-plate door landmark. Connected to subterranean Underthing network.