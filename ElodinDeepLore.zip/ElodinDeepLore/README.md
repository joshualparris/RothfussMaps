# ElodinDeepLore

Research-first app for building the most complete practical picture of Elodin we can inside the Rothfuss game workspace.

## Current structure

- `index.html` - static shell for the lore atlas
- `styles.css` - visual design
- `data.js` - curated Elodin research entries
- `app.js` - filtering and rendering logic

## Research model

Entries are intentionally separated into:

- `Canon` - directly grounded in the books
- `Meta` - author/adaptation-side material
- `Theory` - fan interpretation, kept clearly non-canonical

## Next expansion ideas

- Add direct `Wise Man's Fear` extraction and chapter indexing
- Add an interview/timestamp archive for every Elodin-related Rothfuss quote
- Add a relationship map: Elodin -> Kvothe, Auri, Fela, Hemme, Haven, Naming, Fae
- Add theory scoring by plausibility and textual support
