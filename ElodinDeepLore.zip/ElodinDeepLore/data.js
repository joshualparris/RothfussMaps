const ELODIN_DATA = {
  summaries: [
    {
      title: "Public Face",
      text:
        "Elodin appears erratic, playful, half-feral, and unserious on purpose. That surface behavior hides one of the most frighteningly capable minds at the University.",
    },
    {
      title: "Deep Function",
      text:
        "In canon, he is the living argument that Naming is not just a discipline but a different relationship to reality, perception, and selfhood.",
    },
    {
      title: "Design Warning",
      text:
        "He breaks settings if written lazily. Any Rothfuss-game use should preserve mystery, selective knowledge, and a sense that he notices more than he explains.",
    },
  ],
  gaps: [
    {
      title: "Direct Wise Man's Fear extraction still needed",
      text:
        "This first pass uses canon-aware secondary references for several Wise Man's Fear beats. The next research pass should index a local text or PDF of the novel chapter by chapter.",
    },
    {
      title: "Interview archive is incomplete",
      text:
        "Some community claims point to Rothfuss clips about Elodin's fae blood and secret-royalty implications. Those claims are tracked, but the original clip still needs direct capture and timestamping.",
    },
    {
      title: "Theory ranking can get sharper",
      text:
        "Theories are currently grouped by plausibility and recurrence. A deeper version should score them by textual evidence, author support, and contradiction risk.",
    },
  ],
  entries: [
    {
      id: "first-impression",
      title: "Kvothe's first encounter makes Elodin feel ordinary-looking yet unnervingly powerful",
      category: "Character",
      evidence: "Canon",
      confidence: "High",
      summary:
        "At Kvothe's first admissions interview, Elodin is younger than the other masters, clean-shaven, deep-eyed, and physically unremarkable except for the quality of his attention. Kvothe does not just see him look - he feels it.",
      implications:
        "This is a core design truth. Elodin should rarely be defined by costume or spectacle first. Presence is the first signal of danger.",
      sources: [
        {
          label: "The Name of Wind PDF - page 159",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Local PDF extraction from Kvothe's first admissions scene.",
        },
      ],
    },
    {
      id: "master-namer",
      title: "He is already Master Namer and part of the University's ruling structure",
      category: "University Role",
      evidence: "Canon",
      confidence: "High",
      summary:
        "Admissions and disciplinary scenes identify Elodin formally as Master Namer among the masters who decide tuition, punishment, and rank.",
      implications:
        "Elodin is not a fringe eccentric tolerated on the margins. He is institutionally central even while behaving like a destabilizing force.",
      sources: [
        {
          label: "The Name of Wind PDF - pages 159, 180-185",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Masters table scenes.",
        },
      ],
    },
    {
      id: "former-chancellor",
      title: "Elodin used to be Chancellor despite being very young",
      category: "Backstory",
      evidence: "Canon",
      confidence: "High",
      summary:
        "Simmon and Wilem tell Kvothe that Elodin used to be Chancellor around five years earlier. The revelation lands because he is both young and famously strange.",
      implications:
        "His rise was extraordinary. Before the current story, he had already achieved and lost the highest internal power the University offers.",
      sources: [
        {
          label: "The Name of Wind PDF - page 208",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Simmon and Wilem explain his past.",
        },
      ],
    },
    {
      id: "haven-escape",
      title: "His Haven escape is one of the biggest direct proofs of his naming power",
      category: "Power",
      evidence: "Canon",
      confidence: "High",
      summary:
        "Elodin takes Kvothe into Haven, confronts the reality of broken namers, and demonstrates how he once escaped confinement by breaking stone and opening a path through impossible architecture.",
      implications:
        "He is not merely theoretical. Elodin can work names at a scale that alters prison-like structure and physical boundaries.",
      sources: [
        {
          label: "The Name of Wind PDF - pages 213-217",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Haven sequence and wall-breaking scene.",
        },
      ],
    },
    {
      id: "alder-whin",
      title: "Elodin's treatment of Alder Whin shows intimate knowledge of naming-related damage",
      category: "Psychology",
      evidence: "Canon",
      confidence: "High",
      summary:
        "In Haven, Elodin checks on Alder Whin personally, rebukes staff for locking him in, and speaks grimly about the risks Whin knowingly took as his giller.",
      implications:
        "Elodin's eccentricity is shadowed by guilt, memory, or at least direct familiarity with what Naming can cost minds and lives.",
      sources: [
        {
          label: "The Name of Wind PDF - pages 214-215",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Alder Whin exchange.",
        },
      ],
    },
    {
      id: "teaching-style",
      title: "Elodin teaches through destabilization rather than orderly explanation",
      category: "Teaching",
      evidence: "Canon",
      confidence: "High",
      summary:
        "Kvothe's attempt to study under him is met with pinecone errands, mockery, impossible-seeming demonstrations, and the rooftop lesson. Fela later confirms similarly strange exercises.",
      implications:
        "Any game version of Elodin should resist easy exposition. He teaches by cracking habits of mind, not by delivering neat lectures.",
      sources: [
        {
          label: "The Name of Wind PDF - pages 210-219, 319",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Kvothe's pursuit plus Fela's account.",
        },
      ],
    },
    {
      id: "auri-wind",
      title: "Auri reports seeing Elodin listening to the wind",
      category: "Power",
      evidence: "Canon",
      confidence: "High",
      summary:
        "Auri tells Kvothe she saw Elodin and that he was busy listening to the wind. She treats it as an ordinary statement rather than a metaphor.",
      implications:
        "Auri recognizes Elodin as someone operating on the same strange border between perception, naming, and reality.",
      sources: [
        {
          label: "The Name of Wind PDF - page 244",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Auri conversation.",
        },
      ],
    },
    {
      id: "name-of-fire",
      title: "Kilvin indicates Elodin has the surest grip on the name of fire at the University",
      category: "Power",
      evidence: "Canon",
      confidence: "High",
      summary:
        "After the fishery fire, Kilvin says that if Elodin had been there, matters would have been much simpler and says Elodin has the surest grip on the name of fire.",
      implications:
        "Stone is demonstrated, fire is directly attested, and wind is heavily implied. Elodin almost certainly commands multiple great names.",
      sources: [
        {
          label: "The Name of Wind PDF - pages 315-316",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Kilvin's remarks after the fire.",
        },
      ],
    },
    {
      id: "roof-encounter",
      title: "Elodin appears quietly when Kvothe is emotionally and cognitively thinned out",
      category: "Psychology",
      evidence: "Canon",
      confidence: "High",
      summary:
        "On the roof, when Kvothe is bleeding and unstable, Elodin appears with uncanny timing and frames the moment in terms of how good the night is rather than in ordinary social terms.",
      implications:
        "He repeatedly shows up where naming, brokenness, and altered attention overlap. That pattern feels central to who he is.",
      sources: [
        {
          label: "The Name of Wind PDF - page 332",
          url: "file:///C:/Users/joshua.parris/OneDrive%20-%20Dubbo%20Christian%20School/Documents/03_Projects/RothfussGame/RothfussGameDocs/The%20Name%20of%20Wind.pdf",
          note: "Kvothe rooftop scene.",
        },
      ],
    },
    {
      id: "youngest-student-secondary",
      title: "Secondary sources consistently describe Elodin as the youngest student ever admitted",
      category: "Backstory",
      evidence: "Secondary",
      confidence: "Medium",
      summary:
        "The major Kingkiller fan wiki summarizes Elodin as entering the University at fourteen, becoming a full arcanist by eighteen, later serving as Master Namer and Chancellor.",
      implications:
        "This is probably true, but it should be cross-checked directly against primary text once Wise Man's Fear source extraction is added.",
      sources: [
        {
          label: "Kingkiller Wiki - Elodin page",
          url: "https://kingkiller.fandom.com/wiki/Elodin",
          note: "Secondary summary, not primary canon text.",
        },
      ],
    },
    {
      id: "wmf-expansion",
      title: "Wise Man's Fear appears to expand Elodin from anomaly into major teacher and advisor",
      category: "Wise Man's Fear",
      evidence: "Secondary",
      confidence: "Medium",
      summary:
        "Secondary summaries place Elodin more centrally in Wise Man's Fear: a Naming class, stronger mentoring of Kvothe, reactions around Auri, help restoring Archives access, and later advice about chasing the wind.",
      implications:
        "Book two likely shifts him from atmospheric danger-sign to one of the story's most important interpreters of naming and strange knowledge.",
      sources: [
        {
          label: "Kingkiller Wiki - Elodin summary and appearance list",
          url: "https://kingkiller.fandom.com/wiki/Elodin",
          note: "Secondary recap of Wise Man's Fear scenes.",
        },
      ],
    },
    {
      id: "casting-meta",
      title: "Rothfuss has publicly talked about Elodin in adaptation casting terms",
      category: "Author Meta",
      evidence: "Meta",
      confidence: "High",
      summary:
        "A PAX panel later covered by Winter Is Coming reports Rothfuss saying Lin-Manuel Miranda would be a funny and good Elodin, and that he also had no problem imagining David Tennant in the role.",
      implications:
        "That does not establish lore, but it does signal the kind of energy Rothfuss associates with Elodin: quick, magnetic, verbally alive, and slightly dangerous.",
      sources: [
        {
          label: "Winter Is Coming article on Rothfuss casting comments",
          url: "https://winteriscoming.net/2021/07/23/patrick-rothfuss-wants-lin-manuel-miranda-kingkiller-adaptation/",
          note: "Meta and adaptation-side commentary only.",
        },
      ],
    },
    {
      id: "pronunciation-meta",
      title: "Rothfuss has publicly given a pronunciation for Elodin",
      category: "Author Meta",
      evidence: "Meta",
      confidence: "High",
      summary:
        "The Kingkiller wiki cites a Worldbuilders 2016 video for Elodin's pronunciation. This is useful for future voice work and presentation consistency in any app or game.",
      implications:
        "In a series obsessed with names, even correct pronunciation is worth preserving as part of the character dossier.",
      sources: [
        {
          label: "Worldbuilders 2016 pronunciation video",
          url: "https://www.youtube.com/watch?v=MPEB6NAGoYk",
          note: "Referenced by fandom as the pronunciation source.",
        },
        {
          label: "Kingkiller Wiki references section",
          url: "https://kingkiller.fandom.com/wiki/Elodin",
          note: "Secondary pointer to the video.",
        },
      ],
    },
    {
      id: "fae-blood-theory",
      title: "A major fan theory says Elodin has some fae blood",
      category: "Fae Theory",
      evidence: "Theory",
      confidence: "Medium",
      summary:
        "A very widespread community claim says Rothfuss once stated that Elodin has some fae blood rather than being fully fae. Theory threads repeat this often, but this project still needs the original clip archived directly before treating it as solid author-commentary.",
      implications:
        "If true, it would elegantly explain why Elodin often feels slightly out of phase with ordinary human behavior and why he seems more at ease with unreal thresholds.",
      sources: [
        {
          label: "Reddit theory discussions on Elodin and fae blood",
          url: "https://www.reddit.com/r/KingkillerChronicle/search/?q=Elodin%20fae%20blood",
          note: "Community discussion, not canon.",
        },
      ],
    },
    {
      id: "fae-visit-theory",
      title: "Another persistent theory is that Elodin has visited the Fae or knows it firsthand",
      category: "Fae Theory",
      evidence: "Theory",
      confidence: "Medium",
      summary:
        "This theory draws on his recognition of strange things, his moon-questioning, his composure around Fae-adjacent material, and the overall sense that he knows realities most masters do not.",
      implications:
        "This is useful for creative design but still belongs on the speculation side of the wall until direct text or interview confirmation is captured.",
      sources: [
        {
          label: "Kingkiller Wiki speculation section",
          url: "https://kingkiller.fandom.com/wiki/Elodin",
          note: "Secondary summary of recurring fan theory.",
        },
      ],
    },
  ],
};
